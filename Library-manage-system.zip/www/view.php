<?php
include_once('header.php');
include_once("conn.php");
$query = "select * from book_info";
$stmt= $dbh->query($query);
$arr = array();
$arr2 = array();
$query2 = "select book_id,back_date from borrow_list";
$stmt2= $dbh->query($query2);
foreach ($stmt2 as $row){
    if(strtotime($row['back_date'])>time()){  //仍在借出
        array_push($arr,$row['book_id']);
    }else{                                  //逾期未归
        array_push($arr2,$row['book_id']);
    }
}
echo "</table>";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Examples</title>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
<style type="text/css">
    #box{
        width: 380px;
        margin: 20px auto;
        font-family: 'Microsoft YaHei';
        font-size: 14px;
    }
    input{
        width: 260px;
        border: 1px solid #e2e2e2;
        height: 30px;
        float: left;
        background-image: url(images/search.jpg);
        background-repeat: no-repeat;
        background-size: 25px;
        background-position:5px center;
        padding:0 0 0 40px;
    }
    #search{
        width: 78px;
        height: 32px;
        float: right;
        background: black;
        color: white;
        text-align: center;
        line-height: 32px;
        cursor: pointer;
    }
    .buhuanhang{
        display: inline;
    }
</style>
</head>
<body>
    <div id="box">
        <select id="select1" class="buhuanhang" style="width: 302px;height: 30px;" onchange="gogo(this.id); ">
        <option value="book_name">[书名] 按照书名来查找</option>
        <option value="book_type">[类型] 按照类型来查找</option>
        <option value="book_writer">[作者] 按照作者来查找</option>
        </select>
        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="请输入书名" title="Type in a name">
        <input type="text" id="myInput2" onkeyup="myFunction2()" placeholder="请输入书的类型" title="Type in a name" hidden="hidden">
        <input type="text" id="myInput3" onkeyup="myFunction3()" placeholder="请输入作者" title="Type in a name" hidden="hidden">
    </div>
<script async="true">
var str1 = document.getElementById("select1").value;
function gogo(id){
    var aa = document.getElementById(id);
    var i = aa.selectedIndex;
    if(i==0){
        document.getElementById("myInput").removeAttribute("hidden");
        document.getElementById("myInput2").setAttribute("hidden","true");
        document.getElementById("myInput3").setAttribute("hidden","true");
    }
    if(i==1){
        document.getElementById("myInput").setAttribute("hidden","true");
        document.getElementById("myInput2").removeAttribute("hidden");
        document.getElementById("myInput3").setAttribute("hidden","true");
    }
    if(i==2){
        document.getElementById("myInput").setAttribute("hidden","true");
        document.getElementById("myInput2").setAttribute("hidden","true");
        document.getElementById("myInput3").removeAttribute("hidden");
    }
}

function myFunction() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("k1")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

function myFunction2() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput2");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("k2")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

function myFunction3() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput3");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("k3")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}
</script>
</body>
</html>

<div id="FanYe">
    <ul id="myUL">
        <?php
            $count = 0;
            echo "<h2 style='text-align: center'>图书详情</h2>";
            foreach ($stmt as $row){
                echo "<li>";
                echo "图书号：{$row['id']}&nbsp&nbsp&nbsp";
                echo "<k1>图书名：{$row['name']}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</k1>";
	            echo "<k2>图书类型：{$row['typename']}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<label></k2>";
                echo "<k3>作者：{$row['author']}&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</k3>";
                if(in_array($row['id'],$arr)){
                    echo "<h4 style='color: #FF0000'>已借出</h4>";
                }else if (in_array($row['id'],$arr2)){
                    echo "<h4 style='color: #BBAA00'>逾期未归</h4>";
                } else{
                    echo "<h4 style='color: #11AA00'>在馆</h4>";
                }
	            echo "&nbsp&nbsp&nbsp";
                $id = $row['id'];
                echo "<a href='detailInfor.php?book_id=$id'>详情</a>";
	            echo "</li>";
                if($count>12){
                    $count=0;
                }else{
                    $count++;
                }
            }
        ?>
    </ul>
</div>

<?php
$string = <<<EOT
<div class="layui-box layui-laypage layui-laypage-molv" id="layui-laypage-1">
            <a href="javascript:" class="layui-laypage-first" data-page="0">首页</a>
            <a href="javascript:" class="layui-laypage-pre" data-page="2">上一页</a>
            <a href="javascript:" class="layui-laypage-next" data-page="2">下一页</a>
            <a href="javascript:" class="layui-laypage-last" data-page="2">末页</a>
</div>
EOT;
echo $string;
?>


