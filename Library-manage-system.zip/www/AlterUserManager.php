<?php
include_once('header.php');
include_once("conn.php");
$userid = $_GET['user_id'];
$query ="Select * from user where id='$userid'";
$stmt=$dbh->query($query);
foreach ($stmt as $row){
    $row['id'];
    $row['name'];
    $row['password'];
}
echo "<div id='alter'>";
echo "<h3>用户ID：{$row['id']}</h3>";
echo "<h4>修改信息</h4>";
echo "<form action='' method='post'>";
echo "姓名：<input type='text' name='name' value='{$row['name']}'><br>";
echo "密码：<input type='password' name='password' value='{$row['password']}'><br>";
echo "<button type='submit' name='ok'>提交修改信息</button>";
echo "</form></div>";
if(isset($_POST['ok'])){
    $newName = $_POST['name'];
    $newPassword = md5($_POST['password']);
    $query2 = "update user 
                set pwd='$newPassword',`name` = '$newName' 
                where id='$userid'";
    $stmt=$dbh->query($query2);
    echo "<script>alert('修改本人信息成功!');</script>";
    //header('Location:admin.php');
}
?>
