<?php
    include_once("conn.php");
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>阜蒙县职业教育中心图书馆管理系统注册</title>
    <link href="style/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="register">
    <form action="" method="post">
        <h2>阜蒙县职业教育中心图书馆<br>管理系统用户账号注册</h2>
        <table class="table1">
        <select id="banji" onchange="gogo(this.id)">
            <option disabled selected value>请选择班级或职位</option>
            <option>作物生产技术1班</option>
            <option>作物生产技术2班</option>
            <option>畜禽生产技术1班</option>
            <option>畜禽生产技术2班</option>
            <option>宠物养护与经营1班</option>
            <option>宠物养护与经营2班</option>
            <option>机械加工技术1班</option>
            <option>机械加工技术2班</option>
            <option>焊接技术应用1班</option>
            <option>焊接技术应用2班</option>
            <option>汽车运用与维修1班</option>
            <option>汽车运用与维修2班</option>
            <option>服装陈列与展示设计1班</option>
            <option>服装陈列与展示设计2班</option>
            <option>电子技术应用1班</option>
            <option>电子技术应用2班</option>
            <option>计算机应用1班</option>
            <option>计算机应用2班</option>
            <option>会计事务1班</option>
            <option>会计事务2班</option>
            <option>电子商务1班</option>
            <option>电子商务2班</option>
            <option>幼儿保育1班</option>
            <option>幼儿保育2班</option>
            <option>[兵役]汽车运用与维修1班</option>
            <option>[兵役]汽车运用与维修2班</option>
            <option>物流服务与管理1班</option>
            <option>物流服务与管理2班</option>
            <option>邮轮乘务1班</option>
            <option>邮轮乘务2班</option>
            <option>动漫与游戏制作1班</option>
            <option>动漫与游戏制作2班</option>
            <option>[企业]电子技术应用1班</option>
            <option>[企业]会计事务1班</option>
            <option>[围棋]幼儿保育1班</option>
            <option>教师</option>
        </select><br><br>
        <tr>
            <th>班级/职位：</th>
            <th><input type="text" id="cl" name="class" placeholder="自动生成" readonly="true"></th>
        </tr>
        <tr>
            <th>姓名：</th>
            <th><input type="text" id="na" name="name" placeholder="请输入姓名" disabled="disabled"></th>
        </tr>
        <tr>
            <th>学号/工号：</th>
            <th><input type="text" id="seat" placeholder="请输入(001~999)" align="center" disabled="disabled"></th>
        </tr>
        <tr>
            <th>用户名：</th>
            <th><input type="text" id="uid" name="userid" placeholder="用户id自动生成" disabled="disabled"></th>
        </tr>
        <tr>
            <th>密码：</th>
            <th><input type="password" id="pass" name="password" placeholder="请输入密码" disabled="disabled"></th>
        </tr>
        <tr>
            <th><button type="submit" name="ok1">提交</button></th>
            <th><button type="submit" name="ok2">重置</button></th>
        </tr>
        </table>
        <?php
        if(isset($_POST['ok1'])){
            $name = $_POST['name'];
            $userid = $_POST['userid'];
            $seat = $_POST['seat'];
            $password = md5($_POST['password']);
            $class = $_POST['class'];
            $time = date('Y-m-d h:i:s', time());
            if($name==''){
                echo "<script>alert('名字不能为空!'); location.href='register.php'</script>";
            } else if($password==''){
                echo "<script>alert('密码不能为空！'); location.href='register.php'</script>";
            }else{
                $query = "Insert into user(id,pwd,name,class)values('$userid','$password','$name','$class')";
                if($dbh->query($query)) {
                    echo "<script>alert('注册成功!'); location.href='index.php'</script>";
                } else {
                    echo "<h4 style='color: #d43f3a'>账号信息有误，请重新输入账号! 提示：有可能账号已被注册！</h4>";
                }
            }
        }
        ?>
    </form>
    <a href="index.php" style="float: right;margin-right: 20px;">返回登录界面</a>
</div>
<script>
eve = document.getElementById("seat");
eve2 = document.getElementById("banji");
var text2;
function gogo(id) {
    var aa = document.getElementById(id);
    var i = aa.selectedIndex;
    if(i!=0){
        document.getElementById("seat").removeAttribute("disabled");
        document.getElementById("uid").setAttribute("readonly","readonly");
        document.getElementById("pass").removeAttribute("disabled");
        document.getElementById("na").removeAttribute("disabled");
        document.getElementById("uid").removeAttribute("disabled");
    } else{
        document.getElementById("seat").setAttribute("disabled");
        document.getElementById("uid").setAttribute("disabled");
        document.getElementById("pass").setAttribute("disabled");
        document.getElementById("na").setAttribute("disabled");
        document.getElementById("uid").setAttribute("disabled");
    }
    var mm = ["","zwscjs1","zwscjs2","cqscjs1","cqscjs2","cwyhyjy1","cwyhyjy2","jxjgjs1","jxjgjs2","hjjsyy1","hjjsyy2","qcyyywx1","qcyyywx2","fzclyzssj1","fzclyzssj2","dzjsyy1","dzjsyy2","jsjyy1","jsjyy2","kjsw1","kjsw2","dzsw1","dzsw2","yeby1","yeby2","byqcyyywx1","byqcyyywx2","wlfwygl1","wlfwygl2","ylcw1","ylcw2","dmyyxzz1","dmyyxzz2","qydzjsyy1","qykjsw1","wqyeby1","js"];
    var text = aa.options[i].text;
    text2 = mm[i];
    document.getElementById("cl").value = text;
    document.getElementById("uid").value = text2;
}

eve.onblur = function(){
    var val = document.getElementById("seat").value;
    document.getElementById("uid").value = text2;
    document.getElementById("uid").value += val;
}
eve2.onblur = function(){
    var val = document.getElementById("seat").value;
    document.getElementById("uid").value = text2;
    document.getElementById("uid").value += val;
}
</script>
</body>
</html>