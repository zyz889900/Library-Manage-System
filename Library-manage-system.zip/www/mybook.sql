/*
 Navicat Premium Data Transfer

 Source Server         : OK
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : localhost:3306
 Source Schema         : mybook

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 10/08/2021 22:17:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book_info
-- ----------------------------
DROP TABLE IF EXISTS `book_info`;
CREATE TABLE `book_info`  (
  `id` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` char(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typeid` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `typename` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `author` char(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `press` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `press_time` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ISBN` char(13) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `suoyin_id`(`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of book_info
-- ----------------------------
INSERT INTO `book_info` VALUES ('610301', '母猪的产后护理', '61', '畜牧业', 'ABCD', 'AVAC', '2020-2-2', '45', '111101', '母猪的产后护理，拿错书了');
INSERT INTO `book_info` VALUES ('710201', '计算机基础', '71', '计算机', 'AAA', 'XXX', '2010-10-10', '50', '100100', '计算机基础，适合刚学的人看');
INSERT INTO `book_info` VALUES ('710202', 'C语言课程设计', '71', '计算机', 'AAA', 'XXX', '2011-11-11', '50', '110010', 'C语言不错的书');
INSERT INTO `book_info` VALUES ('710203', '计算机组成与结构', '71', '计算机', 'BBB', 'XXX', '2012-12-12', '45', '110011', '计算机组成与结构基础课程');
INSERT INTO `book_info` VALUES ('710204', 'MySQL数据库', '71', '计算机', 'CCC', 'XXX', '2018-8-8', '60', '111111', 'MySQL课程，适合基础弱的读者观看');
INSERT INTO `book_info` VALUES ('710205', 'Oracle数据库课程设计', '71', '计算机', 'XXX', 'XXX', '2019-9-9', '45', '110101', 'Oracle数据库，适合有一定基础的人看');

-- ----------------------------
-- Table structure for borrow_list
-- ----------------------------
DROP TABLE IF EXISTS `borrow_list`;
CREATE TABLE `borrow_list`  (
  `book_id` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_id` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `borrow_date` date NOT NULL,
  `back_date` date NOT NULL,
  PRIMARY KEY (`book_id`, `user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of borrow_list
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pwd` char(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '12345678',
  `name` char(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `class` char(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '0为挂失,1为正常',
  `admin` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '0为普通用户,1为管理员',
  `last_login_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('jxj1', 'a8f5f167f44f4964e6c998dee827110c', 'zyz', '计算机应用1班', 1, 0, NULL);

SET FOREIGN_KEY_CHECKS = 1;
